﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreAPIDemoBySachinMahore.Services.IRepository;
using CoreAPIDemoBySachinMahore.Services.Repository;
using CoreAPIDemoBySachinMahore.Models.Tables;
using Microsoft.AspNetCore.Http;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CoreAPIDemoBySachinMahore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryAPIController : ControllerBase
    {
        private readonly ICategoryRepository _categoryRepository;
        public CategoryAPIController(ICategoryRepository categoryRepository)
        {
            _categoryRepository=categoryRepository;
        }
        // GET: api/<CategoryAPIController>
        [HttpGet]
        public async Task<IActionResult> GetAllCategoriesAsync()
        {
            try
            {
                var result = await _categoryRepository.GetAllCategoriesAsync();
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error retriving data from the server");
            }
        }
        // POST api/<CategoryAPIController>
        [HttpPost]
        public async Task<IActionResult> AddCategoryAsync(Category category)
        {
            try
            {
                var result = await _categoryRepository.AddCategoryAsync(category);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error retriving data from the server");
            }
        }
        // GET api/<CategoryAPIController>/5
        [HttpGet("{categoryId:int}")]
        public async Task<IActionResult> GetCategoryByCategoryIdAsync(int categoryId)
        {
            try
            {
                var result = await _categoryRepository.GetCategoryByCategoryIdAsync(categoryId);
                return Ok(result);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error retriving data from the server");
            }
        }
        // PUT api/<CategoryAPIController>/5
        [HttpPut]
        public async Task<IActionResult> UpdateCategoryAsync(Category category)
        {
            try
            {
                var result = await _categoryRepository.UpdateCategoryAsync(category);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error retriving data from the server");
            }
        }

        // DELETE api/<CategoryAPIController>/5
        [HttpDelete("{categoryId:int}")]
        public async Task<IActionResult> DeleteCategoryAsync(int categoryId)
        {
            try
            {
                var result = await _categoryRepository.DeleteCategoryAsync(categoryId);
                return Ok(result);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error retriving data from the server");
            }
        }
    }
}
