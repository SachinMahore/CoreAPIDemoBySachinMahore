﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreAPIDemoBySachinMahore.Models.Tables;
using CoreAPIDemoBySachinMahore.Services.IRepository;
using CoreAPIDemoBySachinMahore.Models.AppDbContext;
using Microsoft.EntityFrameworkCore;

namespace CoreAPIDemoBySachinMahore.Services.Repository
{
    public class CategoryRepository:ICategoryRepository
    {
        private readonly AppDbContext _appDbContext;
        public CategoryRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }
        public async Task<IEnumerable<Category>> GetAllCategoriesAsync()
        {
            var categoryList =await _appDbContext.Category.ToListAsync();
            return categoryList;
        }

        public async Task<Category> AddCategoryAsync(Category category)
        {
            _appDbContext.Category.Add(category);
            await  _appDbContext.SaveChangesAsync();
            return category;
        }
        public async Task<Category> GetCategoryByCategoryIdAsync(int categoryId)
        {
            var result = await _appDbContext.Category.FirstOrDefaultAsync(x => x.Id == categoryId);
            if (result == null)
            {
                return null;
            }

            return result;
        }

        public async Task<Category> UpdateCategoryAsync(Category category)
        {
           
            _appDbContext.Category.Update(category);
            await _appDbContext.SaveChangesAsync();
            return category;
        }
        public async Task<Category> DeleteCategoryAsync(int categoryId)
        {
            var result = await _appDbContext.Category.FirstOrDefaultAsync(x => x.Id == categoryId);
            if (result == null)
            {
                return null;
            }
            _appDbContext.Category.Remove(result);
            _appDbContext.SaveChangesAsync();
            return result;
        }

      
        
    }
}
